create function handle_updated_at() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;

alter function handle_updated_at() owner to postgres;

grant execute on function handle_updated_at() to anon;

grant execute on function handle_updated_at() to authenticated;

grant execute on function handle_updated_at() to service_role;

