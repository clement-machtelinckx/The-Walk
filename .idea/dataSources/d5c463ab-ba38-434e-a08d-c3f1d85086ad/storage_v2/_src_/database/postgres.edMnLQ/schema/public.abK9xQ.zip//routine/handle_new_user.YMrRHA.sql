create function handle_new_user() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO public.profiles (id, email, display_name, avatar_url)
    VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'display_name', NEW.raw_user_meta_data->>'avatar_url');
    RETURN NEW;
END;
$$;

alter function handle_new_user() owner to postgres;

grant execute on function handle_new_user() to anon;

grant execute on function handle_new_user() to authenticated;

grant execute on function handle_new_user() to service_role;

